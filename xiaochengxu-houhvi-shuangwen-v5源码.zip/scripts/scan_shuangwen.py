#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""小程序体/盐选体短篇爽文 体检脚本（skill v5）
用法: python3 scan_shuangwen.py 稿.txt [--male 名字1|名字2] [--female 名字]
输出: 硬指标 PASS/WARN 报告 + 黑名单命中行号。只读不改。"""
import sys, re, statistics, argparse

BLACKLIST = [
    # 情绪直说（用动作/对话替代）
    "心里一阵刺痛", "心如刀绞", "心如刀割", "泪流满面", "眼泪止不住", "眼眶一热",
    "怒火中烧", "无名怒火", "血气上涌", "五雷轰顶", "晴天霹雳", "不敢相信自己的眼睛",
    "不敢相信自己的耳朵", "心脏漏跳", "心跳漏了一拍", "喉咙发紧", "鼻子一酸",
    "五味杂陈", "百感交集", "五味俱全", "久久不能平静", "难以言喻", "无以言表",
    # 升华/鸡汤收尾
    "这一刻，我明白了", "原来真正的", "所谓成长", "人生就是这样", "岁月静好",
    "愿我们都能", "值得被温柔以待", "轻舟已过万重山",
    # AI 腔对仗/套话
    "眼底闪过一丝", "眸光一暗", "嘴角勾起一抹", "勾起一抹冷笑", "勾起一抹弧度",
    "邪魅一笑", "宠溺地", "磁性的嗓音", "不容置疑的语气", "与生俱来的",
]

def han(s): return len(re.findall(r'[\u4e00-\u9fff]', s))

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('file')
    ap.add_argument('--male', default='')
    ap.add_argument('--female', default='')
    a = ap.parse_args()
    raw = open(a.file, encoding='utf-8').read()
    lines = [l.strip() for l in raw.split('\n') if l.strip()]
    total = han(raw)
    ok = True
    def rep(cond, msg):
        nonlocal ok
        ok = ok and cond
        print(("PASS " if cond else "WARN ") + msg)

    rep(8000 <= total <= 12000, f"字数 {total}（目标 8000–12000 纯汉字）")
    kd = raw.find('（卡点）')
    if kd < 0:
        rep(False, "未找到（卡点）标记")
    else:
        pct = han(raw[:kd]) / total
        rep(0.40 <= pct <= 0.50, f"卡点位置 {pct:.1%}（目标 40%–50%）")
    plen = [han(l) for l in lines if han(l) > 0]
    rep(statistics.mean(plen) <= 26, f"段均长 {statistics.mean(plen):.1f} 字（≤26；单句成段纪律）")
    rep(max(plen) <= 110, f"最长段 {max(plen)} 字（≤110）")
    dia = sum(han(l) for l in lines if '“' in l)
    rep(0.25 <= dia/total <= 0.50, f"对话占比 {dia/total:.0%}（目标 25%–50%）")
    slen = [han(s) for s in re.split(r'[。！？…]+', raw) if han(s) > 0]
    sd = statistics.pstdev(slen)
    rep(sd >= 5.0, f"句长标准差 {sd:.1f}（≥5，长短句交替；过低=句式单一）")
    hits = [(i+1, w, lines[i][:40]) for i, l in enumerate(lines) for w in BLACKLIST if w in l]
    rep(not hits, f"黑名单命中 {len(hits)} 处")
    for ln, w, ctx in hits[:20]:
        print(f"  行{ln} [{w}] {ctx}")
    sec = [i for i, l in enumerate(lines) if re.fullmatch(r'[0-9]{1,2}', l)]
    if sec:
        bounds = sec + [len(lines)]
        yinzi = sum(han(x) for x in lines[1:bounds[0]])
        counts = [sum(han(x) for x in lines[bounds[n]+1:bounds[n+1]]) for n in range(len(bounds)-1)]
        print(f"逐节字数: 引子 {yinzi} | " + " | ".join(f"第{n+1}节 {c}" for n, c in enumerate(counts)))
    if a.male or a.female:
        sec = [i for i, l in enumerate(lines) if re.fullmatch(r'[0-9]{1,2}', l)]
        sec.append(len(lines))
        mr, fr = re.compile(a.male or '$.'), re.compile(a.female or '$.')
        print("节 | 男主信号 | 女配信号")
        for n in range(len(sec)-1):
            seg = "".join(lines[sec[n]:sec[n+1]])
            print(f"第{n+1}节 | {len(mr.findall(seg))} | {len(fr.findall(seg))}")
    sys.exit(0 if ok else 1)

if __name__ == '__main__':
    main()
